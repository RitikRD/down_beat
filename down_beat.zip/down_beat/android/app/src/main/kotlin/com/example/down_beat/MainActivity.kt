package com.example.down_beat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
