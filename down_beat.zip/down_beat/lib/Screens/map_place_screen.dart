import 'package:down_beat/utils/comman.dart';
import 'package:down_beat/utils/dimention.dart';
import 'package:down_beat/utils/txt.dart';
import 'package:down_beat/widgets/appsearchbar.dart';
import 'package:down_beat/widgets/customappbar.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class Map_Place_Screen extends StatefulWidget {
  @override
  _Map_Place_ScreenState createState() => _Map_Place_ScreenState();
}

class _Map_Place_ScreenState extends State<Map_Place_Screen> {

  GoogleMapController mapController;
  final LatLng _center = const LatLng(26.893802, 75.742226);
  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  @override
  Widget build(BuildContext context) {
    var appBar = CustomAppBar(
        title: Txt.Discover_text,
        toolbarColor: Colors.white,
    );
    return Scaffold(
      appBar: appBar,
      body: Container(
        height: Comman.displaySize(context).height -
        appBar.preferredSize.height -
        MediaQuery.of(context).padding.top -
        Dimentions.bottomiconHeight,
        width: Comman.displaySize(context).width,
        child: Column(
          children: [
            SearchBar(),
            LayoutBuilder(builder: (context , constrains){
              return Stack(
                children: [
                  _googleMap(),
                ],
              );
            })
          ],
        ),
      ),
    );
  }

  // Google Map
  _googleMap(){
    return GoogleMap(
      myLocationEnabled: true,
      zoomControlsEnabled: false,
      onMapCreated: _onMapCreated,
      initialCameraPosition: CameraPosition(
        target: _center,
        zoom: 11.0,
      ),
    );
  }
}
