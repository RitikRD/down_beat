import 'package:down_beat/Screens/place_list_screen.dart';
import 'package:down_beat/modules/band_screen_itemlist.dart';
import 'package:down_beat/utils/comman.dart';
import 'package:down_beat/utils/dimention.dart';
import 'package:down_beat/utils/txt.dart';
import 'package:down_beat/widgets/appsearchbar.dart';
import 'package:down_beat/widgets/bandchildwidget.dart';
import 'package:down_beat/widgets/customappbar.dart';
import 'package:flutter/material.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';

class Band_List_Screen extends StatefulWidget {
  @override
  _Band_List_ScreenState createState() => _Band_List_ScreenState();
}

class _Band_List_ScreenState extends State<Band_List_Screen> with SingleTickerProviderStateMixin {
  TabController _tabController;
  @override
  void initState(){
    super.initState();
    _tabController = TabController(vsync: this, length: 3);
  }
  @override
  void dispose(){
  _tabController.dispose();
  super.dispose();
  }


  PanelController pc = new PanelController();
  bool isPanelClosed = false;
  @override
  Widget build(BuildContext context) {
    var appBar = CustomAppBar(
        title: Txt.Discover_text,
        toolbarColor: Colors.white,
    );
    return Scaffold(
      appBar: appBar,
      body: Stack(
        children: [
          Container(
          height: Comman.displaySize(context).height -
          appBar.preferredSize.height -
          MediaQuery.of(context).padding.top -
          Dimentions.bottomiconHeight,
          width: Comman.displaySize(context).width,
          child: Column(
            children: [
              SearchBar(),
              LayoutBuilder(builder: (context , constrains){
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      _listOfBands(constrains),
                    ],
                  ),
                );
              })
            ],
          ),
        ),
    ],
      ),
    );
  }
  // List Of Band
_listOfBands(BoxConstraints constraints){
    return Container(
      height: Comman.displaySize(context).height*0.71,
      margin: const EdgeInsets.all(10.0),
      child: GridView.builder(
          itemCount: Band.Band_list_items.length,
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 10.0,
          crossAxisSpacing: 5.0,
        ),
          itemBuilder: (context , index){
            return GestureDetector(
                onTap: (){
                  print("true");
                },
                child: BandchildWidget(bandData: Band.Band_list_items[index]));
          }),
    );
}
}
