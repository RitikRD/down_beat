import 'package:flutter/material.dart';

class BandShowChild extends StatelessWidget {
  var showData;
  BandShowChild({Key key, this.showData});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        color: Colors.white,
        child: LayoutBuilder(builder: (context, constrains){
          return Container(
            margin: const EdgeInsets.all(16.0),
            color: Colors.white,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   Text(showData['title'] != null
                       ? showData['title'] : '',
                     textAlign: TextAlign.left,
                     style: TextStyle(
                       fontWeight: FontWeight.w700,
                       fontSize: 17.0),),
                    Text("\$ ${showData['amount'].toString()}",style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.purple[700],
                        fontSize: 18.0),),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(showData['location'] != null
                        ? showData['location'] : '', style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.grey[500],
                        fontSize: 14.0),),
                    Text(showData['buy_text'] != null
                        ? showData['buy_text'] : '', style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 17.0),),
                  ],
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
