import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class PlaceChildWidget extends StatelessWidget {
  var placeData;
  PlaceChildWidget({Key key ,this.placeData});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: LayoutBuilder(builder: (context, constrains){
        return Card(
          elevation: 3.0,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0)),
          color: Colors.white,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                CircleAvatar(
                  backgroundColor: Colors.transparent,
                  radius: 50,
                  backgroundImage: AssetImage(placeData['picture'] != null
                      ? placeData['picture'] : '',
                  ),
                ),
                Text(placeData['title_name'] != null
                    ? placeData['title_name'] : '',style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 17.0),textAlign: TextAlign.center,),
              ],
            ),
          ),
        );
      }),
    );
  }
}
