import 'package:down_beat/utils/comman.dart';
import 'package:down_beat/utils/img.dart';
import 'package:flutter/material.dart';
import 'package:down_beat/utils/txt.dart';

class SearchBar extends StatefulWidget {
  @override
  _SearchBarState createState() => _SearchBarState();
}

class _SearchBarState extends State<SearchBar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color.fromRGBO(163,35,165 ,1.0),
      height: Comman.displaySize(context).height*0.105,
      width: Comman.displaySize(context).width*1,
      child: Container(
        margin: EdgeInsets.all(
            Comman.displayHeight(context) * 0.020),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [
            BoxShadow(
              color: Color.fromRGBO(69, 91, 99, 0.10).withOpacity(0.15),
              spreadRadius: 2,
              blurRadius: 8,
              offset: Offset(0.0, 8.0), // changes position of shadow
            ),
          ],
        ),
        child: TextField(
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.search,
          enabled: false,
          decoration: InputDecoration(
              suffixIcon: IconButton(
                icon: Image(image: AssetImage(Img.searchbar_filter_img),height: 26,width: 26,),
              ),
              prefixIcon: Icon(Icons.search,color: Colors.grey,
              size: 28,
              ),
              hintText: Txt.search_bar_text,
              hintStyle: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.grey,
                fontSize: 15.0,
              ),
              border: InputBorder.none),
        ),
      ),
    );
  }
}
