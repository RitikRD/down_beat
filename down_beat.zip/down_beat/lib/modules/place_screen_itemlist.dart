class Place{
  static var Place_list_items = [
    {
      "picture": "assets/imgs/restro-01.png",
      "title_name": "The Coca-Cola Roxy",
    },
    {
      "picture": "assets/imgs/restro-02.png",
      "title_name": "Nova",
    },
    {
      "picture": "assets/imgs/restro-03.png",
      "title_name": "Nelson & Co.",
    },
    {
      "picture": "assets/imgs/restro-04.png",
      "title_name": "Esuire Lounge",
    },
    {
      "picture": "assets/imgs/restro-05.png",
      "title_name": "Muscle Car Garage",
    },
    {
      "picture": "assets/imgs/restro-06.png",
      "title_name": "The Mermaid Bar",
    },
    {
      "picture": "assets/imgs/restro-01.png",
      "title_name": "Muscle Car Garage",
    },
    {
      "picture": "assets/imgs/restro-02.png",
      "title_name": "The Mermaid Bar",
    },
    {
      "picture": "assets/imgs/restro-06.png",
      "title_name": "Fremont Folk Band",
    },
    {
      "picture": "assets/imgs/restro-01.png",
      "title_name": "Fremont Folk Band",
    },
    {
      "picture": "assets/imgs/restro-02.png",
      "title_name": "Fremont Folk Band",
    },
    {
      "picture": "assets/imgs/restro-06.png",
      "title_name": "Fremont Folk Band",
    },

  ];
}