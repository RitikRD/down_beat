class BandShow{
 static var band_show_item = [
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },
   {
     "title": "The Coca-Cola Roxy",
     "location": "800 Battery Ave, Atlanta, GA",
     "amount": 100,
     "buy_text": "BUY",
   },





 ];
}