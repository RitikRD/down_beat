class Band{
 static var Band_list_items = [
   {
     "picture": "assets/imgs/album-01.png",
     "title_name": "The Dandy Dans",
   },
   {
     "picture": "assets/imgs/album-02.png",
     "title_name": "Eureka Band",
   },
   {
     "picture": "assets/imgs/album-03.png",
     "title_name": "Garrison",
   },
   {
     "picture": "assets/imgs/album-04.png",
     "title_name": "The Black Hats",
   },
   {
     "picture": "assets/imgs/album-05.png",
     "title_name": "Fremont Folk Band",
   },
   {
     "picture": "assets/imgs/album-06.png",
     "title_name": "East Orange",
   },
   {
     "picture": "assets/imgs/album-07.png",
     "title_name": "East Orange",
   },
   {
     "picture": "assets/imgs/album-08.png",
     "title_name": "Fremont Folk Band",
   },
   {
     "picture": "assets/imgs/album-09.png",
     "title_name": "Fremont Folk Band",
   },
   {
     "picture": "assets/imgs/album-10.png",
     "title_name": "Fremont Folk Band",
   },
   {
     "picture": "assets/imgs/album-11.png",
     "title_name": "Fremont Folk Band",
   },
   {
     "picture": "assets/imgs/album-12.png",
     "title_name": "Fremont Folk Band",
   },

 ];
}