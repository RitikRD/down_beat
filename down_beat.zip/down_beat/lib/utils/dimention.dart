class Dimentions {
  static final double bottomNavHeight = 56.0;
  static final double bottomiconHeight = 25.0;
  static final double bottomiconWidth = 25.0;
  static final double statusBarHeight = 24.0;

  static var titlePaddig = 16.0;
}