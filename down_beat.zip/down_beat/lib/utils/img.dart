class Img{
  static String Full_img = "assets/imgs/full_img.png";
  static String appbar_button_img = "assets/imgs/btn_Photo.png";
  static String toggle_image = 'assets/imgs/toggle.png';
  static String settings_image = 'assets/imgs/settings.png';
  static String profile_pic = 'assets/imgs/album-01.png';
  static String ticket_image = 'assets/imgs/ticket.png';
  static String searchbar_filter_img = 'assets/imgs/filter.png';
  static String searchbar_search_img = 'assets/imgs/search.png';
}