class Txt{
  // AppBar Text's
  static String Discover_text = 'Discover';
  static String Signin_text = 'Sign in.';
  static String Reset_text = 'Reset.';
  static String Join_text = 'Join.';
  static String Change_pass_text = 'Change Password';
  static String Setting_text = 'Settings';
  static String Account_text = 'Account';

  // App Button's
  static String Signin_button_text = 'SIGN IN';
  static String Register_button_text = 'REGISTER';
  static String Save_button_text = 'SAVE';

  // OnPage Text's
  static String search_bar_text = "Search by place or artist's name";
  static String Band_venue_text = 'Band/Venue Name';
  static String Address_text = 'Address';
  static String Phone_text = 'Phone #';
  static String Email_tex = 'E-mail';
  static String Payment_text = 'Payment Info';
  static String Web_url_text = 'Website URL';
  static String My_ticket_text = 'My Tickets';
  static String Change_text = 'Change';
  static String Reset_here_text = '  Reset here.';
  static String Forgot_pass_text = 'Forgot your password?';
  static String Logout_text = 'Logout';
  static String Push_notif_text = 'Push Notifications';
  static String Tax_info_text = 'Tax Information';
  static String about_text = "It's a long established fact that s reader will be distracted by the reachable control of a page when looking at it's layout. That point of using lorem lpsum is that it that it has a more-or-less normal distribution of latter, as opposed to using 'Content here, content here', making it look like reachale English. Many desktop publishing packages and web page editor now use Lorem lpsum as their default model text, and a search for 'Lorem ipsum 'will uncover many web sites still in their infancy.";

}
